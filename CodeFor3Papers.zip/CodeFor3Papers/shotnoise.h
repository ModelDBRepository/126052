#ifndef __ShotNoise_Simple_H
#define __ShotNoise_Simple_H

typedef struct __Shotnoise_Simple TShotnoise_Simple;
/*int ShotNoiseSimple_setgetparameters(TShotnoise_Simple *ptr, char *name, double *values, int flag); /* 1 means set, -1 means get */
/*int ShotNoiseSimple_Init(void **ptr, char *parameter_file, int flag);*/

TShotnoise_Simple* ShotNoiseSimple_Create(char *parameter_file);
int ShotNoiseSimple_Destroy(TShotnoise_Simple *ptr);
int ShotNoiseSimple_Start(TShotnoise_Simple *ptr, int frame_size, double sample_rate);
int ShotNoiseSimple_Advance(TShotnoise_Simple *ptr, double** inbuf, double** outbuf); 
int ShotNoiseSimple_Stop(TShotnoise_Simple *ptr);

int ShotNoiseSimple_QueryProperty(TShotnoise_Simple *ptr, char *name, double *values, int flag); 
#endif
