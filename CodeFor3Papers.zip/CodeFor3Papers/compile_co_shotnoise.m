mex load_shotnoise.c shotnoise.c earlab_modules.c
mex run_shotnoise.c load_shotnoise.c shotnoise.c
