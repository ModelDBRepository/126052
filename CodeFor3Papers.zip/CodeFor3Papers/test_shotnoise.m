% More 'advanced' test program for shotnoise model -
% Input rate function varies sinusoidally - Two cycles are shown in final PST

clear *;
tdres = 10e-6;
f = 800; % Hz
frame_size = 200;
t = tdres*(1:frame_size);
rate = 200; % mean rate of each input
InputNums = 15; % # of AN inputs

rt = InputNums*rate*(sin(2*pi*f*t)+1); % simple rate function (i.e. 'pst') will vary sinusoidally

h_sg = load_sgmodel_simple('Default');
h_st = load_shotnoise('Default');

reps = 5000;
nbins = 200;
dt = frame_size*tdres/nbins;
scale = 1/(dt*reps);

efi_set(h_st,'SynapseStrength',[.8 5e-3]); % Shot-noise input parameters (amplitudes = 0.8; tau = 500 usec)
efi_set(h_st,'Threshold',1.0); 
efi_start(h_sg,frame_size,1/tdres);
efi_start(h_st,frame_size,1/tdres);

Ntotal = zeros(nbins+1,1);
Nintotal = Ntotal;
x = (0:nbins)*dt;
x(nbins+1) = inf;
for repidx = 1:reps,
	sptime = efi_advance(h_sg,rt);
	out_sp = efi_advance(h_st,sptime);

	nspikes = length(sptime)-1;
	if(nspikes>0)
		N = histc(sptime(1:nspikes),x);
		if(size(N,1)==1)
			N=N';
		end;
    	Nintotal = N + Nintotal;
    end;

	nspikes = length(out_sp)-1;
	if(nspikes>0)
		N = histc(out_sp(1:nspikes),x);
		if(size(N,1)==1)
			N=N';
		end;
    	Ntotal = N + Ntotal;
    end;
end;
efi_stop(h_sg);
efi_stop(h_st);

save test_shotnoise *;
figure;
plot(x(1:nbins),Ntotal(1:nbins)*scale,x(1:nbins),Nintotal(1:nbins)*scale,'r');
ylabel('Spikes/sec')
xlabel('Time (sec)')
legend('Output','Input')
