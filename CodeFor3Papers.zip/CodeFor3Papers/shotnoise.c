/* *
 * Shot Noise Model which can have different synapse strength, 
 * the inhibitory time constant should be larger than the excitory 
 *
 * */
#include <stdio.h>	
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "shotnoise.h"
#define		FATAL_ERROR_SHOTNOISE_SIMPLE(str) { printf(str); exit(1); };

typedef struct __Shotnoise_EPSG TShotnoise_EPSG;
struct __Shotnoise_EPSG{
	double magnitude, tau;
	double v;
};

struct __Shotnoise_Simple{
	int frame_size;
	double tdres;

	int NumChannels;	/**< Number of the input channels */

	double previous_time;	/**< Previous input spike time */
	double time_per_frame;  /**< Time Duration for each frame */

	TShotnoise_EPSG *epsg;	/**< simulate each input synapse (seperate magnitude and time constant) */
	double Thr; 		/**< Threshold for the shot-noise model */
	double v;		/**< Voltage of the shot-noise model */
	double dead_time;	/**< dead time period of the shot-noise model (0.7ms) */
	double out_sptime_last;	/**< spike time of the last output */
	
	double **sptime;  /* Store the sptime for each channel */
	int *channel_idx; /* The channel index may be changed because of order of spike time */
};
#ifdef DEBUG_SHOTNOISE
	static	FILE *f_debug = NULL;
#endif

/* *************************************************************************** *
 *  Start the module
 * *************************************************************************** */
int ShotNoiseSimple_Start(TShotnoise_Simple *p, int frame_size, double sample_rate){
	int i;
	
	p->frame_size = frame_size;
	p->tdres = 1.0/sample_rate;
	p->sptime = (double**)calloc(sizeof(double*),p->NumChannels);
	p->channel_idx = (int*)calloc(sizeof(int),p->NumChannels);
	
	/* epsg is allocated dynamically */
	for (i=0; i<p->NumChannels; i++) p->epsg[i].v = 0.0;
	p->previous_time = 0;
	p->out_sptime_last = 0;	/**< spike time of the last output */
	p->time_per_frame = frame_size*p->tdres;
return(frame_size);
}

/* *************************************************************************** *
 *  Advance the module
 * *************************************************************************** */
int ShotNoiseSimple_Advance(TShotnoise_Simple *p, double** inbuf, double** outbuf) 
{
  double time, time_next;
  int countOut;
  int i;
  int MaxSpikesPerFrame,total_spikes_buffer;
  double *sptime_now,*out_sptime;
  int channel_left, channel_start, channel_now;
  double dur;
  TShotnoise_EPSG *epsg;

	MaxSpikesPerFrame = 400;
	total_spikes_buffer = MaxSpikesPerFrame;
	/* 
	 * alloc the memory for spike time, there is always -1 at the end of the channel 
	 * so the memory size should +1 */
	out_sptime = (double*)realloc(NULL,sizeof(double)*(total_spikes_buffer+1));
  
	countOut = 0;
	p->previous_time -= p->time_per_frame;		/**< Previous spike time */
	p->out_sptime_last -= p->time_per_frame;	/**< spike time of the last output */

	sptime_now = *inbuf;
	channel_left = p->NumChannels;

	/* Split and Order these channels, as the earliest sptime comes to the first channel */
	channel_left--;
	channel_now = 0;
	p->sptime[channel_left] = sptime_now;
	p->channel_idx[channel_left] = channel_now;
	while(channel_left>0){
		if(sptime_now[0] < 0) {
			time = sptime_now[1]; /* starting spike time of next channel */
			i = channel_left;
			channel_now++;
			/* Reorder the already ordered channels due to the new coming channel */
			while ( (i<p->NumChannels) && (time>p->sptime[i][0]) ){
				p->channel_idx[i-1] = p->channel_idx[i];
				p->sptime[i-1] = p->sptime[i];
				i++;
			};
			/* Position the new split channel */
			p->sptime[i-1] = sptime_now+1;
			p->channel_idx[i-1] = channel_now;
			channel_left--;
		};
		sptime_now++;
	};

	/* Now the channels is ordered, we process the spikes for most recent channels */
	channel_start = 0;
	while(channel_start<p->NumChannels)
	{
  		/* Get Next Spike Time */
		time = p->sptime[channel_start][0];
		if (time>=0)	/* Else get the next channel */
		{
			if((time - p->out_sptime_last) >= p->dead_time) /* In the dead time, skip this spike */
			{	
				/* Time difference between the previous input spike and current time */
				dur = (time-p->previous_time);
				/* process the spike time, that is not in the dead time period */
				p->previous_time = time;
				p->v = 0;
				for (i=0, epsg=p->epsg; i<p->NumChannels; i++, epsg++)
				{	/* calculate the time decay, and the */
					epsg->v *= exp(-dur/epsg->tau); /* take the current voltage */
					p->v += epsg->v;
				};

				epsg = p->epsg+p->channel_idx[channel_start]; /* take the current channels */
				epsg->v += epsg->magnitude;
				p->v += epsg->magnitude;

				/* Here we judge if there is a output spikes */
				if(p->v >= p->Thr){	/* Now we need to record the spike time */
				    out_sptime[countOut++] = time; /* The next spike time */
				    p->out_sptime_last = time;	/* remember the this output spike time */
				    for (i=0; i<p->NumChannels; i++)	p->epsg[i].v = 0.0;

				    if(countOut >= total_spikes_buffer){    /* Realloc the memory */
					total_spikes_buffer += MaxSpikesPerFrame;
					out_sptime = 
						(double*)realloc(out_sptime,sizeof(double)*(total_spikes_buffer+1));
				    };
				};
			}; /* End of processing spikes not in dead time */
			/* if there is more than one channel left, we need to resort the channels!!! */
			if( (channel_start+1)<p->NumChannels )
			{
				/* Point to the next spike */
				sptime_now = p->sptime[channel_start]+1;
				time_next = *sptime_now;
				channel_now = p->channel_idx[channel_start];
				i = channel_start+1;
				while ( (i<p->NumChannels) && (time_next>p->sptime[i][0]) ){
					/* Switch the Channle number, and sptime number */
					p->channel_idx[i-1] = p->channel_idx[i];
					p->sptime[i-1] = p->sptime[i];
					i++;
				};
				p->sptime[i-1] = sptime_now;
				p->channel_idx[i-1] = channel_now;
			} else { /* Here we don't need to order the channels */
				p->sptime[channel_start]++;
			};			
		} else { /* If time > 0 */
			channel_start++;
		};
	};	/* End of while */
	*outbuf = out_sptime;	/* This buffer (sptime) will be released by matlab !!! */
	out_sptime[countOut++] = -1;
return(countOut);
}

int ShotNoiseSimple_Stop(TShotnoise_Simple *p)
{
		if(p->sptime)	free(p->sptime);		p->sptime = NULL;
		if(p->channel_idx) free(p->channel_idx);	p->channel_idx = NULL;
		return(0);
}

char** ShotNoiseSimple_HelpInfo(void);
int ShotNoiseSimple_QueryProperty(TShotnoise_Simple *p, char *name, double *values, int flag)
{
	int error = 0;
	int i;
	char ***info;
	if(strcmp(name,"NumChannels")==0){
		if(flag==1) {
			p->NumChannels = (int)(floor(*values+0.1));
			if(p->epsg!=NULL) free(p->epsg);
			if((p->epsg=(TShotnoise_EPSG*)calloc(sizeof(TShotnoise_EPSG),p->NumChannels))==NULL)
				FATAL_ERROR_SHOTNOISE_SIMPLE("Shotnoise_Simple : Alloc epsg error\n");
#ifdef DEBUG_SHOTNOISE
	f_debug = fopen("shotnoise_debug.txt","a+");
	fprintf(f_debug,"\nset NumChannels : %d, epsg:%d",p,p->epsg);
	fclose(f_debug);
#endif
			
		} else if(flag==2){
			*values = p->NumChannels;
		} else if(flag==3){
			*values = 1;
		} else if(flag==4)
			*values = 0;
		else error = 2;
	} else if(strcmp(name,"SynapseStrength")==0){
		/* If the synapse conductance is negative, meaning that this is inhibitory input, else excitory 
		 * The array is as following format : G_Max_1, Tau_1, G_Max_2, Tau_2 ...
		 * */
		if(flag==1) {
			for(i=0; i<p->NumChannels; i++, values+=2) 
				p->epsg[i].magnitude = values[0], p->epsg[i].tau = values[1]; /* 0.1ms , 20nS; */
		} else if(flag==2) {
			for(i=0; i<p->NumChannels; i++, values+=2) 
				values[0] = p->epsg[i].magnitude, values[1] = p->epsg[i].tau; /* 0.1ms , 20nS; */
		} else if(flag==3) {
				*values = p->NumChannels*2;
		} else if(flag==4)
				*values = 0;
		else error = 2;
	} else if(strcmp(name,"Threshold")==0){
		switch(flag){
			case 1:		p->Thr = *values; 	break;
			case 2:		*values = p->Thr; 	break;
			case 3:		*values = 1;		break;
			case 4:		*values = 0;		break;
			default: error = 2;
		};
	} else if(strcmp(name,"dead_time")==0){
		switch(flag){
			case 1:		p->dead_time = *values; break;
			case 2:		*values = p->dead_time; break;
			case 3:		*values = 1;		break;
			case 4:		*values = 0;		break;
			default: error = 2;
		};
	} else if(strcmp(name,"HelpInfo")==0){
		info = (void*)(values);
		*info = ShotNoiseSimple_HelpInfo();
	} else {
		error = 1;
	};
return(error); /* Nothing to set and get */
}

char** ShotNoiseSimple_HelpInfo(void)
{
static char *Info[]={\
"Properties:\n",\
"  dead_time       -> dead time of the shotnoise model (0.7e-3 second)\n",\
"  NumChannels     -> Number of input spike channels (1)\n",\
"  SynapseStrength -> magnitude(Siment) and time constant(second) of each channel (2*NumChannels array, [20e-9; 100e-6\n",\
"  Threshold       -> Threshold(Siment) of the model [30e-9]\n",\
"                     Note: you can set Threshold equals 1, and change the corresponding magnitude\n",\
"\0\0"};
return(Info);
}
TShotnoise_Simple* ShotNoiseSimple_Create(char *parameter_file)
{
	TShotnoise_Simple *p;
	double values[4];

	p = calloc(sizeof(TShotnoise_Simple),1);
	if(p!=NULL){
		p->epsg = NULL;
		values[0] = 1;
		ShotNoiseSimple_QueryProperty(p,"NumChannels",values,1);
		values[0] = 20e-9; values[1] = 100e-6; /* To make the Ae comparable with Rothman's model */
		ShotNoiseSimple_QueryProperty(p,"SynapseStrength",values,1);
		values[0] = 30e-9;
		ShotNoiseSimple_QueryProperty(p,"Threshold",values,1);
		values[0] = .7e-3;
		ShotNoiseSimple_QueryProperty(p,"dead_time",values,1);
	};
return(p);
}

int ShotNoiseSimple_Destroy(TShotnoise_Simple *p){
	if(p->epsg!=NULL) free(p->epsg);
	free(p);
return(0);
};

