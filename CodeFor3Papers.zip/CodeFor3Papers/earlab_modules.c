/* *******************************************************************
 * A matlab module loader. It return a module runtime pointer 
 * as a integer back to the matlab.
 *                                         Xuedong Zhang 9/18/2003
 * *******************************************************************/
#include "mex.h"
#include "earlab_modules.h"
#define	EFI_MATLAB_FATAL_ERROR(str) {printf(str); exit(1);}

/* ************************************************************************
 * If you want to make your module be loaded into matlab, all thing you should
 * do is to write a following function ( please see sample file )
 * *********************************************************************** */
extern void populate_interface(T_EFI_Module_Runtime_V1* efi_runtime);

/* ******************************************************* *
 * Following Code is same for all modules                  *
 * ******************************************************* */
T_EFI_Module_Runtime_V1* init_module(char *ParameterFile)
{
	T_EFI_Module_Runtime_V1* ptr;
	ptr = (T_EFI_Module_Runtime_V1*)calloc(sizeof(T_EFI_Module_Runtime_V1),1);
	if(ptr==NULL) EFI_MATLAB_FATAL_ERROR("Allocate Module Runtime Error\n");

	ptr->SetGet = NULL;
	ptr->SetGet_FromID = NULL;
	ptr->runtime_signature = NULL;
	ptr->Version_major = 1;
	ptr->Version_minor = 0;
	populate_interface(ptr);
	ptr->handle = ptr->Create(ParameterFile);
return(ptr);
};

/* The gateway routine */
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  #define NDIMS 2
  const int dims[]={1,1};
  unsigned int *start_of_pr;
  int buflen;
  char *config_filename=NULL;

  /* Get ParameterFile Name */
  if((nrhs>=1)&&(mxIsChar(prhs[0]) == 1))  
  {  
	buflen = (mxGetM(prhs[0]) * mxGetN(prhs[0])) + 1;
	config_filename = mxCalloc(buflen, sizeof(char));
	mxGetString(prhs[0], config_filename, buflen);
  };  
  /* Create a 1-by-1 array of unsigned 32-bit integers. for returned value */
  plhs[0] = mxCreateNumericArray(NDIMS,dims,mxUINT32_CLASS,mxREAL);

  /* Get the pointer of returned buffer and assign the pointer as integer */
  start_of_pr = (unsigned int *)mxGetData(plhs[0]);
  *start_of_pr = (unsigned int)(init_module(config_filename));
}
