/* *******************************************************************
 * A shotnoise model.
 *                                         Xuedong Zhang 11/9/2003
 * *******************************************************************/
#include <math.h>
#include "mex.h"
#include "earlab_modules.h"
#define	EFI_MATLAB_FATAL_ERROR(str) {printf(str); exit(1);}

void printHelpInfo(void)
{
static char *helpinfo[] = {\
"spiketime = run_shotnoise(spike_in, N, para, tdres, dur);\n",\
"spiketime = run_shotnoise(spike_in, N, para, tdres, dur, dead_time);\n",\
"  run the shot noise model with N input channels.\n",\
"Input Parameters : \n",\
"  spike_in -> one dimention array store the input spike time (in seconds) of each channel,\n",\
"              each channel ended with -1 and the spike time is in incremental order.\n",\
"              So two channel spike time should be something like [1e-3 5e-3 -1 3.5e-3 -1],\n",\
"              and even there is no spikes in the channel you should end the channel with -1\n",\
"  N        -> Number of input channels\n",\
"  para     -> 2*N array indicate the magnitude and time constant of each channel\n",\
"              The threshold of the model is always set as 1\n",\
"  tdres    -> time domain resolution to run the model\n",\
"  dur      -> experiment duration, all the spike time must be between [0 dur] (in second)\n",\
"  dead_time-> dead time of the shotnoise model after firing (default = 0 second)\n",\
"\n",\
"Output Parameters : \n",\
"  spiketime-> Output spike time of the shotnoise model, ended with -1\n",\
"\0\0"};

	int i=0;
	while(1){
		if(helpinfo[i][0]=='\0') break;
		mexPrintf(helpinfo[i]); i++;
	}
}

T_EFI_Module_Runtime_V1* init_module(char *ParameterFile);

/* The gateway routine */
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  T_EFI_Module_Runtime_V1*  module_pr;
  char *config_filename=NULL;
  double values[2], tdres, dur,dead_time;
  double *v_pr, *out_pr, *out_pr_good;
  int status;
  int buflen;

  /* Get ParameterFile Name */
  if((nrhs<5)||(nrhs>6))  
  {
	printHelpInfo();
  } else {
	/* Create the module, (load_module) */
	module_pr = init_module(config_filename);
	/* Set properties of the model, efi_set(...) */
	/* spiketime = run_shotnoise(spike_in, N, para, tdres, dur, dead_time); */
	status = module_pr->SetGet(module_pr->handle,"NumChannels",mxGetData(prhs[1]),1);
	if(status!=0) mexWarnMsgTxt("This module doesn't support this Property.\n");
	values[0] = 1.0;	/* Threshold equals 1 */
	status = module_pr->SetGet(module_pr->handle,"Threshold",(void*)values,1);
	if(status!=0) mexWarnMsgTxt("This module doesn't support this Property.\n");
	status = module_pr->SetGet(module_pr->handle,"SynapseStrength",(void*)mxGetPr(prhs[2]),1);
	if(status!=0) mexWarnMsgTxt("This module doesn't support this Property.\n");
	dead_time = 0;
	if(nrhs == 6)
	{
		v_pr = mxGetPr(prhs[5]);
		dead_time = v_pr[0];
	};
	status = module_pr->SetGet(module_pr->handle,"dead_time",(void*)(&dead_time),1);
	if(status!=0) mexWarnMsgTxt("This module doesn't support this Property.\n");
	
	v_pr = mxGetPr(prhs[3]);
	tdres = v_pr[0];
	v_pr = mxGetPr(prhs[4]);
	dur = v_pr[0];

	/* Start the module, efi_start */
  	module_pr->Start(module_pr->handle, floor(0.5+dur/tdres), (1/tdres));

	/* Advance the module, efi_advance */
	plhs[0] = mxCreateDoubleMatrix(100,1, mxREAL);
	v_pr   = mxGetPr(prhs[0]);
	out_pr = mxGetPr(plhs[0]);
	buflen = module_pr->Advance(module_pr->handle,&v_pr,&out_pr);

	/* we need to adjust the output dimension !!!!! */
	plhs[0] = mxCreateDoubleMatrix(buflen,1, mxREAL);
	out_pr_good = mxGetPr(plhs[0]);
	memcpy(out_pr_good,out_pr,sizeof(double)*buflen);
	free(out_pr);

	/* Stop the module, efi_stop */
	module_pr->Stop(module_pr->handle);

	/* Free the module */
	free(module_pr);
  };
}

extern void populate_interface(T_EFI_Module_Runtime_V1* efi_runtime);
/* ******************************************************* *
 * Following Code is same for all modules                  *
 * ******************************************************* */
T_EFI_Module_Runtime_V1* init_module(char *ParameterFile)
{
	T_EFI_Module_Runtime_V1* ptr;
	ptr = (T_EFI_Module_Runtime_V1*)calloc(sizeof(T_EFI_Module_Runtime_V1),1);
	if(ptr==NULL) EFI_MATLAB_FATAL_ERROR("Allocate Module Runtime Error\n");

	ptr->SetGet = NULL;
	ptr->SetGet_FromID = NULL;
	ptr->runtime_signature = NULL;
	ptr->Version_major = 1;
	ptr->Version_minor = 0;
	populate_interface(ptr);
	ptr->handle = ptr->Create(ParameterFile);
return(ptr);
};

