#include "earlab_modules.h"
#include "shotnoise.h"
/* ************************************************************************
 * If you want to make your module be loaded into matlab, all changes you 
 * should make is in this function (plus include the your own headfile)
 * *********************************************************************** */
void populate_interface(T_EFI_Module_Runtime_V1* efi_runtime)
{
        /* Change the Corresponding Function to your own module Functions */
	efi_runtime->Create 	= 	(void*)ShotNoiseSimple_Create;
	efi_runtime->Destroy	=	(void*)ShotNoiseSimple_Destroy;
	efi_runtime->Start	=	(void*)ShotNoiseSimple_Start;
	efi_runtime->Stop	=	(void*)ShotNoiseSimple_Stop;
	efi_runtime->Advance	=	(void*)ShotNoiseSimple_Advance;
	/* Make it equals to NULL if you don't support this */
	efi_runtime->SetGet	=	(void*)ShotNoiseSimple_QueryProperty;
return;
};
