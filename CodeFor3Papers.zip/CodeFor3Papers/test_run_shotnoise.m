% Very simple test program sample - Shot nosie model with 2 inputs
% There's one spike at time 0 on 1st input, and 2 spikes on 2nd input (each list of spikes times is terminated by -1)
% The  2 inputs to the shotnoise model cell each have have amplitude 0.8 (w.r.t. threshold = 1.0) and Tau=1 msec.

% type: run_shotnoise in Matlab to see all parameters described

run_shotnoise([0 -1 1e-3 5e-3 -1],2,[0.8 0.8; 1e-3 1e-3],10e-6, 10e-3,0.0)
