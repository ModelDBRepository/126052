/* ***********************************
 *
 * EarLab Module Interface for matlab
 * 
 * ***********************************/
#ifndef __EARLAB_MODULES_H
#define __EARLAB_MODULES_H

#ifdef __cplusplus
extern "C"{ /* Make the head file friendly to C++ */
#endif

#define FLAG_EFI_SetProperty	1
#define FLAG_EFI_GetProperty	2
#define FLAG_EFI_GetPropertySize	3	/* unit is in the sizeof(double) */
/* If we want to set PropertyName with variable size, this is very handy */
#define FLAG_EFI_SetPropertySize	4	/* unit is in the sizeof(double) */
#define FLAG_EFI_GetPropertyType	5	/* Type of the Property : Not used now */
#define FLAG_EFI_GetPropertyID		6	/* Type of the Property : Not used now */

#define FLAG_EFI_TypeDouble	1
#define FLAG_EFI_TypeString	2
#define FLAG_EFI_TypeIntegeter	3
#define FLAG_EFI_TypeFloat	4		/* Do we need this */

#define Err_EFI_NO_PropertyName	1		/* Cann't find the property name */
#define Err_EFI_NO_PropertyFunction	2   /* Don't know how to manipilate the property */

/*  A Matlab Module Loader returns a Runtime Structure  */
typedef struct __EFI_Module_Runtime_V1 T_EFI_Module_Runtime_V1;
typedef T_EFI_Module_Runtime_V1 T_EFI_Module_Runtime;

typedef struct __ModuleHandle ModuleHandle;

/* **************************************************************** *
 * Specification for the mandatory interface, Subject to change     *
 * **************************************************************** */

/* Create the Module handle, return NULL if fail */
typedef  ModuleHandle* (*__EFI_FUN_Create)(char *ParameterFile);
/* Destroy the Module handle, return 0 if succeed, else return the error code */
typedef  int (*__EFI_FUN_Destroy)(ModuleHandle *h);
/* Start the module, return zero if succeed, else return the error code 
 * SUBJECT TO CHANGE, original return frame_size if succeed */
typedef int (*__EFI_FUN_Start)(ModuleHandle *h, int frame_size, double sample_rate);
/* Advance the Module handle with some input */
typedef int (*__EFI_FUN_Advance)(ModuleHandle *h, double** in, double** out);
  /* SUBJECT TO CHANGE:
   * For Module Users who want to call this function directly:
   * 
   *   usually input buffer (*in) will not change the value, and output buffer (*out) should
   *   have the same size as the input buffer allocated by your program. 
   *
   *   You need to keep the address of the output buffer into another variable (other than *out),
   *   because the advance(...) will change this value (*out). If that happens, the advance(...)
   *   allocated its own buffer with size of the returned value. You should free this memory 
   *   after calling the advance(...).
   *
   * For Module Writers :
   *
   *   If your module have the same size of input and output (Like Fixed as frame_size),
   *   you don't need to allocate your own memroy for output buffer. If not, you should 
   *   allocate the output buffer and return the size of the buffer you allocated.
   *   
   *   You should also better ganrantee the advance(...) will run successfule even intput 
   *   and output buffer have the same address
   *
   * Todo: If the backbone know exactly what is the size of the output, 
   * It shoube be possible to tell the module to do that, (PropertiesID: "MemeoryAllocation")
   * Instead if the module always want the backbone to provide the buffer, it would be nice
   * to have this feature (PropertiesID: "OutputSize" "InputSize")
   * 
   * Return : return the number of output samples generated (zero/-1? means error)
   * if spike trains : return the total number of the spikes [Include the terminator(-1)]
   * 
   **/

/* Stop the module handle, return 0 if succeed, else return the error code */
typedef int (*__EFI_FUN_Stop)(ModuleHandle *h);

/* **************************************************************** *
 * Specification for the interface extensiont, Subject to change    *
 * **************************************************************** */
typedef struct __EFI_PropertyType EFI_PropertyType;
/* Property Inquiry, Maybe we should change the name??? QueryProperty */
typedef int (*__EFI_FUN_SetGet)(ModuleHandle *h, char *PropertyName, EFI_PropertyType* values, int flag);
  /* Some modules don't want this be supported,
   *   So if you support it, please set the minor version  = 1
   * flag = 1 : set Property Value
   * flag = 2 : get Property Value
   * flag = 3 : get Size of Property ( in sizeof(double) / sizeof(PropertyType) )
   * flag = 4 : set Size of Property
   * flag = 5 : get Property Type (double/string/int) (Implemented in minor version > 2)
   * flag = 6 : get Property ID
   * return : 0 normal, else is the error number
   * */

/* Well, If you know the ID of the Property, you can use this function to speedup,
 * but it will be not specified at 1.0 */
typedef int (*__EFI_FUN_SetGet_FromID)(ModuleHandle *h, int *PropertyID, EFI_PropertyType* values, int flag);

/* ****************************************************** *
 *            Runtime Structures                          *
 * ****************************************************** */
/* Runtime Structure for Version 1 : Version_major=1, runtime_signature = NULL */
struct __EFI_Module_Runtime_V1{
  void *runtime_signature;  	/* Not used now, always set it to NULL for version 1.x */
  short Version_major;  	/* Major Version of Specification, should be 1 */
  short Version_minor;  	/* Minor Version of Specification, should be 0 */

  /* Following are the Function Handles, Like Virtural Function in C++ */
  __EFI_FUN_Create	Create;		/* Create the module */
  __EFI_FUN_Destroy	Destroy;	/* Destroy the module */

  __EFI_FUN_Start	Start;		/* Start the module */
  __EFI_FUN_Advance	Advance;	/* Advance the Module */
  __EFI_FUN_Stop	Stop;		/* Stop the module */

  __EFI_FUN_SetGet	SetGet;		/* Set/Get the Property of a module */

  __EFI_FUN_SetGet_FromID	SetGet_FromID;		/* Set/Get the Property of a module from ID */

  /* Handle for module, different for different modules */
  ModuleHandle *handle; /* module instance data pointer */
};

/* This structure is totally depreciated, PLEASE DO NOT USE IT */
typedef struct __EFI_Module_Runtime_OLD T_EFI_Module_Runtime_OLD; 
T_EFI_Module_Runtime_V1* efi_convert_from_old( T_EFI_Module_Runtime_OLD* old_efi_runtime);

#ifdef __cplusplus
} /* End of C declaration, Be friendly to C++ */
#endif

#endif
